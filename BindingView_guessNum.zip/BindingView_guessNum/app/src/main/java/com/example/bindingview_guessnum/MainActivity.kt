package com.example.bindingview_guessnum

import android.content.Intent
import android.os.Binder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.example.bindingview_guessnum.databinding.ActivityMainBinding
import java.util.*

class MainActivity : AppCompatActivity() {
    val TAG : String = MainActivity::class.java.simpleName
    private lateinit var handler: Handler
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //val title = findViewById<TextView>(R.id.title)
        //val showtext = findViewById<TextView>(R.id.showtext)
        //val guessbt = findViewById<Button>(R.id.guessbutton)
        //val resetbt = findViewById<Button>(R.id.resetbutton)
        //val edit = findViewById<TextView>(R.id.input)


        var ans : Int = Random().nextInt(100)+1
        var max = 100
        var min = 1

        var showstr : String
        var titlestr : String

        binding.guessbutton.setOnClickListener {
            val inputnum : Int = binding.input.text.toString().toInt()

            if (inputnum==ans){
                showstr=getString(R.string.bingo)
                Toast.makeText(this,getString(R.string.resetstr), Toast.LENGTH_LONG).show()

                handler.postDelayed({
                    min=1
                    max=100
                    ans= Random().nextInt(100)+1
                    binding.title.text=getString(R.string.title_name)
                    binding.showtext.text="~~~~~"
                },6000)


            }else{
                if (inputnum>ans){
                    max=inputnum
                    showstr=getString(R.string.smaller)
                }else{
                    min=inputnum
                    showstr=getString(R.string.bigger)
                }
                titlestr="$min ~ $max"
                binding.title.text=titlestr
            }
            binding.showtext.text=showstr
        }
        binding.resetbutton.setOnClickListener {

            min=1
            max=100
            ans=Random().nextInt(100)+1
            binding.title.text=getString(R.string.title_name)
            binding.showtext.text="~~~~~"
        }


    }
}

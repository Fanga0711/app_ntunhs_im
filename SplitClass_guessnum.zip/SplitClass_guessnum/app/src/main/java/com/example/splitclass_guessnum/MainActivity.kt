package com.example.splitclass_guessnum

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.provider.Settings.Global.getString
import android.provider.Settings.Secure.getString
import android.provider.Settings.System.getString
import android.widget.Toast
import androidx.core.content.res.TypedArrayUtils.getString
import com.example.splitclass_guessnum.databinding.ActivityMainBinding
import java.util.*

class MainActivity : AppCompatActivity() {


    val TAG : String = MainActivity::class.java.simpleName
    private lateinit var handler: Handler
    private lateinit var binding: ActivityMainBinding
    private lateinit var guesslogic : classguessnum
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        handler = Handler(Looper.getMainLooper())
        //val title = findViewById<TextView>(R.id.title)
        //val showtext = findViewById<TextView>(R.id.showtext)
        //val guessbt = findViewById<Button>(R.id.guessbutton)
        //val resetbt = findViewById<Button>(R.id.resetbutton)
        //val edit = findViewById<TextView>(R.id.input)


        guesslogic = classguessnum()

        //var showstr : String
        //var titlestr : String

        binding.guessbutton.setOnClickListener {
           guesslogic.guessNum(binding.input.text.toString().toInt(),binding,handler)
            }

        }

}


package com.example.splitclass_guessnum

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import java.util.*
import android.os.Handler
import com.example.splitclass_guessnum.databinding.ActivityMainBinding

class classguessnum  {

        var ans : Int = Random().nextInt(100)+1
        var max = 100
        var min = 1

        fun guessNum(inputnum:Int,binding: ActivityMainBinding,handler: Handler) {
            if (inputnum==ans){
                binding.showtext.text="bingo"
                Toast.makeText(binding.root.context,"reset in 6s", Toast.LENGTH_LONG).show()
                handler.postDelayed({
                    min=1
                    max=100
                    ans= Random().nextInt(100)+1
                    binding.title.text="guess number"
                    binding.showtext.text="~~~~~"
                },6000)

            }else{
                if (inputnum>ans){
                    max=inputnum
                    binding.showtext.text="smaller"

                }else{
                    min=inputnum
                    binding.showtext.text="bigger"
                }

            }
            binding.title.text="$min~$max"
        }

    }
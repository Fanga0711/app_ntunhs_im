package com.example.guessnumber

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.util.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val title = findViewById<TextView>(R.id.title)
        var _input = findViewById<TextView>(R.id.input)
        val guessButton = findViewById<Button>(R.id.guessButton)
        val resetButton = findViewById<Button>(R.id.ResetButton)

        var validate_num : Int

        var ans = Random().nextInt(100)+1

        var max : Int = 100
        var min : Int = 1
        guessButton.setOnClickListener {
            validate_num=_input.text.toString().toInt()-ans
            var ans_str : String="Bingo!!"
            if(validate_num>0){
                ans_str="Smaller!"
            }else if(validate_num<0){
                ans_str="Bigger!"
            }
            Toast.makeText(this,ans_str,Toast.LENGTH_LONG).show()
            if(ans > _input.text.toString().toInt()){
                min=_input.text.toString().toInt()
            }else if (ans < _input.text.toString().toInt()){
                max=_input.text.toString().toInt()
                }
            title.text = min.toString()+" ~ "+max.toString()
        }
        resetButton.setOnClickListener {
            ans = Random().nextInt(100)+1
            title.text="Let's guess one more time!"
        }

    }
}
package com.example.guess_number

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import java.util.Random

class MainActivity : AppCompatActivity() {

    private lateinit var handler: Handler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        handler= Handler(Looper.getMainLooper())

        val title = findViewById<TextView>(R.id.title)
        val showtext = findViewById<TextView>(R.id.showtext)
        val guessbt = findViewById<Button>(R.id.guessbutton)
        //val resetbt = findViewById<Button>(R.id.resetbutton)
        val edit = findViewById<TextView>(R.id.input)

        var ans : Int = Random().nextInt(100)+1
        var max = 100
        var min = 1

        var showstr : String
        var titlestr : String

        guessbt.setOnClickListener {
            val inputnum : Int = edit.text.toString().toInt()

            if (inputnum==ans){
                showstr=getString(R.string.bingo)
                Toast.makeText(this,getString(R.string.resetstr),Toast.LENGTH_LONG).show()

                handler.postDelayed({
                    min=1
                    max=100
                    ans=Random().nextInt(100)+1
                    title.text=getString(R.string.title_name)
                    showtext.text="~~~~~"
                    },6000)


            }else{
                if (inputnum>ans){
                    max=inputnum
                    showstr=getString(R.string.smaller)
                }else{
                    min=inputnum
                    showstr=getString(R.string.bigger)
                }
                titlestr="$min ~ $max"
                title.text=titlestr
            }
            showtext.text=showstr
        }
        //resetbt.setOnClickListener {

            //min=1
            //max=100
            //ans=Random().nextInt(100)+1
            //title.text=getString(R.string.title_name)
            //showtext.text="~~~~~"
        //}

    }
    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
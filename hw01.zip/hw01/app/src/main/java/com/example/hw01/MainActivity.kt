package com.example.hw01

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val title = findViewById<TextView>(R.id.title);
        var guess = findViewById<TextView>(R.id.guessscope)
        val guessbutton = findViewById<Button>(R.id.guess_button)
        val resetbutton = findViewById<Button>(R.id.again_button)
        val enter = findViewById<EditText>(R.id.entertext)

        var validate_num : Int
        var answer : Int = Random().nextInt(100) + 1
        var guessnum : Int
        var max : Int = 100
        var min : Int = 1
        var scope : String
        guessbutton.setOnClickListener{
            guessnum = enter.text.toString().toInt()
            validate_num = guessnum-answer
            var ans_str : String

            if (validate_num > 0){
                ans_str = "SMALLER!:O"
            }else if (validate_num < 0){
                ans_str = "BIGGER!UWU"
            }else{
                ans_str = "BINGO!!"

            }
            Toast.makeText(this,ans_str,Toast.LENGTH_LONG).show()


            if (guessnum>answer){
                max = guessnum
            }else if(guessnum<answer){
                min = guessnum
            }
            scope = min.toString() +"~"+ max.toString()

            if (answer!=guessnum){
                guess.text = scope
            }else{
                guess.text = ans_str
            }
        }

        resetbutton.setOnClickListener {
            answer = Random().nextInt(100) + 1
            title.text = "LET'S GUESS AGAIN"
            guess.text = ":DDD"
        }

    }
}
package com.example.midtermtest

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*

class MainActivity : AppCompatActivity() {
    private val TAG = "MainActivity"
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputtel = findViewById<EditText>(R.id.telinput)
        val adultspinner = findViewById<Spinner>(R.id.adultspinner)
        val kidspinner = findViewById<Spinner>(R.id.kidspinner)
        val adultadapter = ArrayAdapter.createFromResource(this,R.array.adults,android.R.layout.simple_spinner_dropdown_item)
        val kidadapter = ArrayAdapter.createFromResource(this,R.array.kids,android.R.layout.simple_spinner_dropdown_item)
        val sendbutton = findViewById<Button>(R.id.button)
        adultspinner.adapter=adultadapter
        kidspinner.adapter=kidadapter

        var adultmsg :String=""
        var kidmsg :String=""
        var chairmsg:String=""
        var tablewaremsg : String=""
        val chaircheck = findViewById<CheckBox>(R.id.chaircheckBox)
        val tablewarecheck = findViewById<CheckBox>(R.id.tablewarecheckBox)
        adultspinner.onItemSelectedListener = object:AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>, view: View, pos : Int, id : Long) {
                val adultnumber = resources.getStringArray(R.array.adults)
                adultmsg="大人人數 : "+adultnumber[pos].toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                adultmsg="未填寫大人人數"
            }
        }
        kidspinner.onItemSelectedListener = object:AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>, view: View, pos : Int, id : Long) {
                val kidnumber = resources.getStringArray(R.array.kids)
                kidmsg="小孩人數 : "+kidnumber[pos].toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                kidmsg="未填寫小孩人數"
            }
        }
        sendbutton.setOnClickListener {
            if (chaircheck.isChecked){
                chairmsg="需"+chaircheck.getText().toString()
                }
            else
                chairmsg="不需"+chaircheck.getText().toString()


            if (tablewarecheck.isChecked){
                tablewaremsg="需"+tablewarecheck.getText().toString()
                }
            else
                tablewaremsg="不需"+tablewarecheck.getText().toString()


            var bundle=Bundle()
            var resultmsg = "訂位電話 : "+inputtel.text.toString()+"\n"+adultmsg+"\n"+kidmsg+"\n"+chairmsg+"\n"+tablewaremsg
            bundle.putString("result",resultmsg)
            Log.e(TAG,resultmsg)
            var resultintent = Intent(this,resultpage::class.java)
            resultintent.putExtra("key",bundle)
            startActivity(resultintent)

        }

    }
}
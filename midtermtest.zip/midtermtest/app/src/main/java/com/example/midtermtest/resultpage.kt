package com.example.midtermtest

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class resultpage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultpage)

        val resultxt = findViewById<TextView>(R.id.result)
        val backbutton = findViewById<Button>(R.id.backbutton)
        val text = intent.getBundleExtra("key")?.getString("result").toString()

        resultxt.setText(text)

        backbutton.setOnClickListener {
            var mainintent = Intent(this,MainActivity::class.java)
            startActivity(mainintent)
        }
    }
}
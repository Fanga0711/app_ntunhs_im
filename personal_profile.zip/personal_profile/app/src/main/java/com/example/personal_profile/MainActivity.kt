package com.example.personal_profile

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Calendar

class MainActivity : AppCompatActivity() {
    private fun setDateFormat(year:Int,month:Int,day:Int):String{
        return "$year-${month+1}-$day"
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val acctext = findViewById<EditText>(R.id.acctext)
        val pwdtext = findViewById<EditText>(R.id.pwdtext)
        val nametext = findViewById<EditText>(R.id.nametext)
        val emailtxt = findViewById<EditText>(R.id.emailtext)
        val phonetxt = findViewById<EditText>(R.id.phonetext)




        val groupGender = findViewById<RadioGroup>(R.id.gendergroup)
        val btnMale = findViewById<Button>(R.id.malebutton)
        val btnFemale = findViewById<Button>(R.id.femalebutton)

        val btndone = findViewById<Button>(R.id.donebutton)
        val btnins1 = findViewById<CheckBox>(R.id.ins1)
        val btnins2 = findViewById<CheckBox>(R.id.ins2)
        val btnins3 = findViewById<CheckBox>(R.id.ins3)
        val btnins4 = findViewById<CheckBox>(R.id.ins4)

        val bdaytext = findViewById<EditText>(R.id.bdatetext)

        var gender =""
        groupGender.setOnCheckedChangeListener { _, checkedId ->
            gender = when (checkedId)
            {
                R.id.femalebutton -> btnFemale.text.toString()
                R.id.malebutton -> btnMale.text.toString()
                else -> "I don't know"
            }
        }

        bdaytext.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH)

            DatePickerDialog(this,{_,year,month,day ->
                run {
                    var format = setDateFormat(year,month,day)
                    bdaytext.setText(format)
                }
            },year, month, dayOfMonth).show()
        }
        btndone.setOnClickListener {
            var msg  =""
            if (btnins1.isChecked()){
                msg = msg + btnins1.getText().toString()
            }
            if (btnins2.isChecked()){
                msg = msg + "、" + btnins2.getText().toString()
            }
            if (btnins3.isChecked()){
                msg = msg + "、" + btnins3.getText().toString()
            }
            if (btnins4.isChecked()){
                msg = msg + "、" + btnins4.getText().toString()
            }
            AlertDialog.Builder(this).setTitle("Your Choose:").setMessage("Account:"+acctext.text+"\nPassword:"+pwdtext.text+"\nName:"+nametext.text+"\nEmail:"+emailtxt.text+"\nPhone:"+phonetxt.text+"\nBirthday:"+bdaytext.text+"\nGender:$gender"+"\nInterest:$msg").create().show()
        }

    }
}
package com.example.switchpage

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView

class rpsgame : AppCompatActivity() {

    private lateinit var txtcom : TextView
    private lateinit var txtResult : TextView
    private lateinit var btnscissors : ImageButton
    private lateinit var btnrock : ImageButton
    private lateinit var btnpaper : ImageButton
    private lateinit var comimageView : ImageView
    private lateinit var rpsbacktocenter : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rpsgame)

        txtcom = findViewById(R.id.txtcom)
        txtResult = findViewById(R.id.txtResult)
        btnscissors = findViewById(R.id.btnScissors)
        btnrock = findViewById(R.id.btnRock)
        btnpaper = findViewById(R.id.btnPaper)
        comimageView = findViewById(R.id.comImage)
        rpsbacktocenter = findViewById(R.id.RpsbacktoCenter)

        btnrock.setOnClickListener {

            playGame(Choice.ROCK)
        }
        btnscissors.setOnClickListener {
            playGame(Choice.SCISSORS)
        }
        btnpaper.setOnClickListener {
            playGame(Choice.PAPER)
        }
        rpsbacktocenter.setOnClickListener {
            var mainIntent = Intent(this,MainActivity::class.java)
            startActivity(mainIntent)
            finish()
        }

        }
        enum class Choice{
            SCISSORS, ROCK, PAPER
        }
        fun playGame(playerChoice: Choice){
            val choices = Choice.values()
            val computerchoices = choices[java.util.Random().nextInt(choices.size)]
            if (computerchoices == Choice.PAPER){
                comimageView.setImageResource(R.drawable.paper)
            }else if (computerchoices == Choice.SCISSORS){
                comimageView.setImageResource(R.drawable.scissor)
            }else{
                comimageView.setImageResource(R.drawable.rock)
            }
            when{
                playerChoice==computerchoices -> {
                    txtcom.setText(getChoiceString(computerchoices))
                    txtResult.setText(R.string.draw)
                }
                playerChoice == Choice.SCISSORS && computerchoices == Choice.PAPER ||
                        playerChoice == Choice.ROCK && computerchoices == Choice.SCISSORS ||
                        playerChoice == Choice.PAPER && computerchoices == Choice.ROCK -> {
                    txtResult.setText(R.string.win)
                }
                else -> {
                    txtcom.setText(getChoiceString(computerchoices))
                    txtResult.setText(R.string.lose)
                }
            }
        }
        fun getChoiceString(choice: Choice) : Int{
            return when(choice){
                Choice.SCISSORS -> R.string.scissors
                Choice.ROCK -> R.string.rock
                Choice.PAPER -> R.string.paper
            }
    }
}